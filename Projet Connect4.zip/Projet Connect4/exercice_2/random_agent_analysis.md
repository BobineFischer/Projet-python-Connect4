## Partie 3 : Analyse

### Tâche 2.7 : Analyse statistique

```python
#6 réalisations de 100 parties

win pourcentage :  {'player_0': 50.0, 'player_1': 50.0}
total of drawns :  0
minimum of moves :  7
maximum of moves :  38
average number of moves :  {'player_0': 11.41, 'player_1': 10.91, 'total': 22.32}

win pourcentage :  {'player_0': 61.0, 'player_1': 38.0}
total of drawns :  2
minimum of moves :  7
maximum of moves :  42
average number of moves :  {'player_0': 11.52, 'player_1': 10.91, 'total': 22.43}

win pourcentage :  {'player_0': 47.0, 'player_1': 53.0}
total of drawns :  0
minimum of moves :  9
maximum of moves :  40
average number of moves :  {'player_0': 10.74, 'player_1': 10.27, 'total': 21.01}

win pourcentage :  {'player_0': 70.0, 'player_1': 29.0}
total of drawns :  2
minimum of moves :  7
maximum of moves :  42
average number of moves :  {'player_0': 10.33, 'player_1': 9.63, 'total': 19.96}

win pourcentage :  {'player_0': 55.0, 'player_1': 45.0}
total of drawns :  0
minimum of moves :  8
maximum of moves :  41
average number of moves :  {'player_0': 11.09, 'player_1': 10.54, 'total': 21.63}

win pourcentage :  {'player_0': 59.0, 'player_1': 41.0}
total of drawns :  0
minimum of moves :  7
maximum of moves :  40
average number of moves :  {'player_0': 11.18, 'player_1': 10.59, 'total': 21.77}
```

1. Le premier joueur à jouer gagne la plupart du temps.

2. Le joueur 1 semble avoir un avantage étand donné qu'il gagne à chaque fois plus de 50% des parties.

3. La moyenne de coup tourne autour de 10 par joueur donc 20 au total, avec le premier joueur ayant une moyenne plus élevée car il a plus de jetons sur les cases donc plus de chances d'obtenier 4 jetons alignés par hasard et plus de chance de les placer au milieu en premier. Les parties durent au minimum 7 coups et maximum 42.

4. La fréquence de match nul ne semble pas depasser les 3%.